import React, { useState, useEffect } from "react";
import CarouselSlider from "./Sliders/CarouselSlider";
import NavBar from "./Zee5Header/NavBar";
import './Home.css'
import Slider1 from "./Sliders/Slider1";


const Home = () => {

  return (
    <div>
      <header>
        <NavBar />
      </header>
      <CarouselSlider />
      <Slider1/>
    </div>
  );
};

export default Home;
