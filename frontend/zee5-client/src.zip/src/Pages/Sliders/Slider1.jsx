import React from "react";
import { IoIosArrowForward } from "react-icons/io";

const Slider1 = () => {
  return (
    <section id="section1Block">
      <article>
        <div className="topSection">
          <h2>Exclusive Movies on ZEE5</h2>
          <p>
            More
            <span>
              <IoIosArrowForward />
            </span>
          </p>
        </div>
        <div className="bottomSection">
          <div className="img1Block">
            <a href="/">
              <img src="/images/static1.webp" alt="StaticImg1" />
            </a>
          </div>
          <div className="img2Block">
            <a href="/">
              <img src="/images/static2.webp" alt="StaticImg2" />
            </a>
          </div>
          <div className="img3Block">
            <a href="/">
              <img src="/images/static3.webp" alt="StaticImg3" />
            </a>
          </div>
        </div>
      </article>
    </section>
  );
};

export default Slider1;
