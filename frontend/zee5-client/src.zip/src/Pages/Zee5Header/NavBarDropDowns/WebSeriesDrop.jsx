import React from 'react'

const WebSeriesDrop = () => {
  return (
    <div>WebSeriesDrop</div>
  )
}

export default WebSeriesDrop