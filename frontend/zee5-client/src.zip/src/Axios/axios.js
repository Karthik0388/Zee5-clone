import axios from "axios";

const axiosInstance = axios.create({
  baseURL: "http://localhost:5000/api/auth",
});

// request interceptor for adding token
axiosInstance.interceptors.request.use((config) => {
  // add token to request headers
  config.headers['Authorization'] = localStorage.getItem('TOKEN');
  return config;
});          

export default axiosInstance;
