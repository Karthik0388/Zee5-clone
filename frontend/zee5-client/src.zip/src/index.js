import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import DropDownApiProvider from './Components/ContextApis/DropDownApi';
import "./zee5.css"



ReactDOM.render(
  <DropDownApiProvider>
    <App />
  </DropDownApiProvider>,
  document.getElementById("root")
);